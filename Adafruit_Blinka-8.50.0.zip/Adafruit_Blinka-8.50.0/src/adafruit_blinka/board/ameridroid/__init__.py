# SPDX-FileCopyrightText: 2024 Rippanda12
#
# SPDX-License-Identifier: MIT
"""Boards definition from ameriDroid"""
